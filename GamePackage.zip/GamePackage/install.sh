#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Registering game with firewall (needs your password)..."
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --add "$SCRIPT_DIR/game"
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --unblockapp "$SCRIPT_DIR/game"
xattr -cr "$SCRIPT_DIR"
echo "Done! Run play.sh to launch."
